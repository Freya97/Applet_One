// pages/contect/contect.js
var conf = require('../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchValue: '',
    listData: null,
    listname: [],
    selectedData: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: conf.ip+'/user/listAuditor',
      data: {
        dept: wx.getStorageSync("dept")
      },
      method: 'POST',
      header: {
        "Content-Type": "application/json"
      },
      success: function (res) {
        var name = new Array()
        for (var i = 0; i < res.data.length; i++) {
          name: name.push(res.data[i].uname.substring(res.data[i].uname.length - 2))
        }
        that.setData({
          listData: res.data,
          listname: name
        })
      }
    })
  },

  radiogroupBindchange:function(e){
    console.log('拨号：' + e.detail.value)
    wx.makePhoneCall({
      phoneNumber: e.detail.value,
      success:function(){
        console.log('拨打成功！')
      }
    })
  }
})





