// pages/contect/contect.js
var conf = require('../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchValue: '',
    listData: null,
    listname: [],
    selectedData: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: conf.ip+'/MavenTest1/user/listAuditor',
      data: {
        dept: wx.getStorageSync("dept")
      },
      method: 'POST',
      header: {
        "Content-Type": "application/json"
      },
      success: function (res) {
        var name = new Array()
        for (var i = 0; i < res.data.length; i++) {
          name: name.push(res.data[i].uname.substring(res.data[i].uname.length - 2))
        }
        that.setData({
          listData: res.data,
          listname: name
        })
      }
    })
  },

  radiogroupBindchange:function(e){
    console.log('拨号：' + e.detail.value)
    wx.makePhoneCall({
      phoneNumber: e.detail.value,
      success:function(){
        console.log('拨打成功！')
      }
    })
  },
  



  // search:function(key){
  //   var that =this;
  //   key:'listData'
  //   var arr = []
  //   for(let i in res.data){
  //     res.data[i].show = false;

  //   }
  // },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})





