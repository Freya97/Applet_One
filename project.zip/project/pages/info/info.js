// pages/index/info.js
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dept:''
  },

 
  onLoad: function (options) {
    var dept = wx.getStorageSync('dept')
    this.setData({
      dept:dept
    });

  },

  
  
})