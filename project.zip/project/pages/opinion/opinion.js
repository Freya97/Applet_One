var conf = require('../../config.js')
var app = getApp();
Page({
  data: {
    temp1: '',
    checkreason: '',
    text1: '',
    ta: '',
    status: '',
    hidden: true
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    var params = JSON.parse(options.params);

    var status = params.status
    console.log(status, '000')
    this.setData({
      ta: params.id,
      status: params.status
    })
    console.log(status, 'llll')
  },
  reasonInput: function(e) {
    this.setData({
      text1: e.detail.value,
    })
  },

  formSubmit: function(e) {
    var that = this
    that.setData({
      hidden: false
    })
    var auditor = wx.getStorageSync('username')
    var formData = that.data.text1
    var temp = that.data.ta
    var status = that.data.status
    console.log(status, '987')
    wx.request({
      url: status == '同意' ? conf.ip + '/list/passByIds' : conf.ip + '/list/unpassByIds',
      method: 'POST',
      data: {
        id: temp,
        auditor: auditor,
        checkreason: formData
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        that.setData({
          hidden:true
        })
        wx.navigateTo({
          url: '../checked/checked?id=' + temp + '&re=0',
        })
      }

    })
  },

})