var conf = require('../../config.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    listData: null,
    temp1: null,
    selectedData: [],
    selectedFlag: [false],
    hidden:true,
    req:true
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    wx.request({
      url: conf.ip + '/list/listCountByDate',
      data: {
        dept: wx.getStorageSync("dept")
      },
      method: 'POST',
      header: {
        "Content-Type": "application/json"
      },
      success: function(res) {
        that.setData({
          listData: res.data
        })
        console.log(that.data.listData);
        if (res.data == '') {
          wx.showToast({
            title: '近一周内暂无数据',
            icon: 'none',
            duration: 4000
          })
        }
      }
    })
  },
  checkboxgroupBindchange: function(e) {
    var udate = e.detail.value
    console.log("udate=" + udate)
    this.setData({
      selectedData: udate
    })

  },


  fileout: function(e) {
    this.setData({
      hidden: false,
    });
    if (wx.getStorageSync("admin") == 1) {
      var data = this.data.selectedData.join(',');
      console.log("选择的日期是：" + data)
      var that = this
      if (that.data.selectedData == '') {
        wx.showToast({
          title: '请选择日期',
          icon: 'none',
          duration: 2000
        })
        that.setData({
          hidden: true,
          selectedFlag: [false],
          req: true
        })
      } else if(this.data.req==true){
        this.setData({
          req:false
        })
        wx.request({
          url: conf.ip + '/email/email',
          data: {
            udate: data,
            dept: wx.getStorageSync("dept"),
            email: wx.getStorageSync("email")
          },
          method: 'POST',
          header: {
            "Content-Type": "application/json"
          },
          success: function(res) {         
            that.setData({
              hidden: true,
              selectedFlag: [false],
              req:true
            });
            console.log("返回result=" + res.data)
            if (res.data == '1') {
              wx.showToast({
                title: '导出成功',
                icon: 'success',
                duration: 2000
              })
            } else {
              if (res.data == '-2') {
                wx.showToast({
                  title: '导出失败，请重试',
                  icon: 'none',
                  duration: 2000
                })
              } else if (res.data = '-1') {
                wx.showToast({
                  title: '导出的数据不存在',
                  icon: 'none',
                  duration: 2000
                })
              } else if (res.data = '0') {
                wx.showToast({
                  title: '请选择日期',
                  icon: 'none',
                  duration: 2000
                })
              }
            }
          }
        })
      }
    } else {
      wx.showToast({
        title: '对不起，您没有权限',
        icon: 'none',
        duration: 2000
      })
    }
  },

  changeToggle: function(e) {
    var index = e.currentTarget.dataset.index;
    if (this.data.selectedFlag[index]) {
      this.data.selectedFlag[index] = false;
    } else {
      this.data.selectedFlag[index] = true;
    }
    this.setData({
      selectedFlag: this.data.selectedFlag
    })
  },

})