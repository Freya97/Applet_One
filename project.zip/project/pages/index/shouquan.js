// pages/index/shouquan.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf94501534eca9f66&redirect_uri=https%3a%2f%2f%2fcl.beta.csfjn.com%2fa%2fatt%2fuser%2fgetOpenid2&response_type=code&scope=snsapi_base&state=123#wechat_redirect'
  },

  onLoad:function(){
    console.log('我返回了')
    setTimeout(function () {
      wx.reLaunch({
        url: '../info/info',
      })
    }, 3000) 
  },
 
})