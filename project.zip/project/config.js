export const ip ='https://cl.beta.csfjn.com/att'

